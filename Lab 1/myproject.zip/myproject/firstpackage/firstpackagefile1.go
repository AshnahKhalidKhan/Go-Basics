package firstpackage

import "fmt"

func Function1FromFirstPackage() {
	fmt.Println("This is first package ki file 1")
}