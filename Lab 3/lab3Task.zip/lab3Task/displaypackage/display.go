package displaypackage

import (
	"fmt"
)

func DisplayInfo(heading map[int]string, m map[int]string) {
	fmt.Println()
	for key, value := range m {
		fmt.Print(heading[key], ":", value)
	}
	fmt.Println()
}
