package main

import (
	"bufio"
	"fmt"
	"os"
	"time"

	// "sync"
	// "strconv"
	d "lab3/displaypackage"
	s "lab3/storagepackage"
)


var mymap1 map[int]string
var headings = map[int]string{0: "Name", 1: "ERP", 2: "CLASS", 3: "PROGRAM", 4: "COURSE", 5: "CGPA", 6: "AGE", 7: "HEIGHT", 8: "WEIGHT", 9: "GENDER", 10: "RELIGION", 11: "UNIVERSITY", 12: "CITY", 13: "COUNTRY"}

func main() {
	mymap1 = make(map[int]string)

	for i := 0; i < 14; i++ {
		mymap1[i] = ""
	}

	reader := bufio.NewReader(os.Stdin)

	fmt.Println("Name:")
	name, _ := reader.ReadString('\n')
	mymap1[0] = name

	fmt.Println("ERP:")
	erp1, _ := reader.ReadString('\n')
	// erp,_ := strconv.Atoi(erp1);
	mymap1[1] = erp1

	fmt.Println("Class:")
	class, _ := reader.ReadString('\n')
	mymap1[2] = class

	fmt.Println("Program:")
	program, _ := reader.ReadString('\n')
	mymap1[3] = program

	fmt.Println("Course:")
	course, _ := reader.ReadString('\n')
	mymap1[4] = course

	fmt.Println("CGPA:")
	cgpa1, _ := reader.ReadString('\n')
	// cgpa,_ := strconv.Atoi(cgpa1);
	mymap1[5] = cgpa1

	fmt.Println("Age:")
	age1, _ := reader.ReadString('\n')
	// age,_ := strconv.Atoi(age1);
	mymap1[6] = age1

	fmt.Println("Height:")
	height1, _ := reader.ReadString('\n')
	// height,_ := strconv.Atoi(height1);
	mymap1[7] = height1

	fmt.Println("Weight:")
	weight1, _ := reader.ReadString('\n')
	// weight,_ := strconv.Atoi(weight1);
	mymap1[8] = weight1

	fmt.Println("Gender:")
	gender, _ := reader.ReadString('\n')
	mymap1[9] = gender

	fmt.Println("Religion:")
	religion, _ := reader.ReadString('\n')
	mymap1[10] = religion

	fmt.Println("University:")
	university, _ := reader.ReadString('\n')
	mymap1[11] = university

	fmt.Println("City:")
	city, _ := reader.ReadString('\n')
	mymap1[12] = city

	fmt.Println("Counntry:")
	country, _ := reader.ReadString('\n')
	mymap1[13] = country

	go d.DisplayInfo(headings, mymap1)

	// makingastructure
	// fmt.Println();
	// fmt.Println();
	// fmt.Println();
	//fmt.Println(name, erp1, class, program, course, cgpa1, age1, height1, weight1, gender, religion, university, city, country);

	fmt.Println("Text File Name:")
	// textfilename, _ := reader.ReadString('\n')
	var textfilename = "file.txt"

	fmt.Println("CSV File Name:")
	// csvfilename, _ := reader.ReadString('\n')
	var csvfilename = "file.csv"

	t1 := time.Now()
	go s.StoreInFile(textfilename, mymap1)
	go s.StoreInFile(csvfilename, mymap1)
	t2 := time.Now()
	TimeTaken := t2.Sub(t1)
	go fmt.Println("Time taken:", TimeTaken)
	time.Sleep(5 * time.Second)
}
