package main

import (
	"fmt"
	// "time"
	"sync"
)

var wg sync.WaitGroup
var mymap1 = []int{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20}

func PrintEven(m []int) {
	for v := range m {
		if m[v]%2 == 0 {
			// time.Sleep(200 * time.Millisecond)
			fmt.Print(m[v], ",")
		}
	}
	fmt.Println()
	wg.Done()
}

func PrintOdd(m []int) {
	for v := range m {
		if m[v]%2 != 0 {
			// time.Sleep(200 * time.Millisecond)
			fmt.Print(m[v], ",")
		}
	}
	fmt.Println()
	wg.Done()
}

// wg.Add(3)
// wg.Done()
// wg.Wait()

func main() {
	wg.Add(2)
	go PrintEven(mymap1)
	go PrintOdd(mymap1)
	wg.Wait()
	// time.Sleep(5 * time.Second)
}
