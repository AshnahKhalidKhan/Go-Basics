package splitarray

func Q1(x [10]int) ([10]int, [10]int) {
	var narray[]int
	var parray[]int
	var n[10]int
	var p[10]int
	
	for i := 0; i < 10; i++ {
		if x[i] < 0 {
			narray = append(narray, x[i])
		} else {
			parray = append(parray, x[i])
		}
	}

	for i := 0; i < len(narray); i++ {
		n[i] = narray[i]
	}

	for i := 0; i < len(parray); i++ {
		p[i] = parray[i]
	}

	return n, p
}