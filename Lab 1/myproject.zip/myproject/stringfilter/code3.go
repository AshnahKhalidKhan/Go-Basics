package stringfilter

func StringByteVowelString(s string) string {
	data := []byte(s)
	result := ""
	for i := 0; i < len(data); i++ {
		if data[i] != 'A' && data[i] != 'a' && data[i] != 'E' && data[i] != 'e' && data[i] != 'I' && data[i] != 'i' && data[i] != 'O' && data[i] != 'o' && data[i] != 'U' && data[i] != 'u' {
			result += string(data[i])
		}
	}
	return result
}