package calculator

func Add(x[4][4]int, y[4][4]int) [4][4]int {
	var result[4][4]int
	for i := 0; i < 4; i++ {
		for j := 0; j < 4; j++ {
			result[i][j] = x[i][j] + y[i][j]
		}
	}
	return result
}

func Sub(x[4][4]int, y[4][4]int) [4][4]int {
	var result[4][4]int
	for i := 0; i < 4; i++ {
		for j := 0; j < 4; j++ {
			result[i][j] = x[i][j] - y[i][j]
		}
	}
	return result
}

func Mul(x[4][4]int, y[4][4]int) [4][4]int {
	var result[4][4]int
	for i := 0; i < 4; i++ {
		for j := 0; j < 4; j++ {
			result[i][j] = x[i][j] * y[i][j]
		}
	}
	return result
}

func Div(x[4][4]int, y[4][4]int) [4][4]int {
	var result[4][4]int
	for i := 0; i < 4; i++ {
		for j := 0; j < 4; j++ {
			result[i][j] = x[i][j] / y[i][j]
		}
	}
	return result
}