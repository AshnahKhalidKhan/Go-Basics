package storagepackage

import (
	"os"
)

func StoreInFile(filename string, m map[int]string) {
	f, _ := os.Create(filename)
	defer f.Close()
	for key := range m {
		f.WriteString(m[key])
	}
}
