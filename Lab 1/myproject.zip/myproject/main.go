// package main

// import (
// 	"fmt"
// 	p1 "pdcproject/firstpackage"
// 	p2 "pdcproject/secondpackage"
// )

// var arr1 [4]string
// var newarr [4][4]int

// //for slice, length is NOT mentioned when declaring
// var myslice[] int

// func main() {
// 	myintarray := [5]int{5, 4, 3, 2, 1}
// 	arr2 := [3]string{"I am one", "I am two", "I am three"}
// 	fmt.Println(myintarray)
// 	fmt.Println(arr2)

// 	mymultidimarr := [2][2]string{{"1x1", "1x2"}, {"2x1", "2x2"}}
// 	fmt.Println(mymultidimarr)

// 	arr1[0] = "This is us putting a value in an array"
// 	fmt.Println(arr1)

// 	for i := 0; i < 4; i++ {
// 		arr1[i] = fmt.Sprint(i)
// 	}

// 	//use ellipses with do-while loop
// 	//this is NOT dynamic binding; this will only be done ONCE at run time
// 	elipsesarr:= [...]string{"dowhile1", "dowhile2", "dowhile3", "dowhile4", "dowhile5"}
// 	fmt.Println("Elements of the array: ", elipsesarr)
// 	fmt.Println("Length of the array is:", len(elipsesarr))

// 	//Slices are same as lists in Python; NOT used when doing something related to hardware
// 	myslice.sort!

// 	fmt.Println("Testing testing 1 2 3..................")
// 	p1.Function1FromFirstPackage()
// 	p2.Function1FromSecondPackage()
// }





package main

import (
	"fmt"
	s "pdcproject/splitarray"
	c "pdcproject/calculator"
	f "pdcproject/stringfilter"
)

func main() {
	num := [10]int{-1, 2, 3, 4, 77, 100, -2, 8, -5, 4}
	var narray, parray = s.Q1(num)
	fmt.Println("Original numbers:", num)
	fmt.Println("Narray:", narray)
	fmt.Println("Parray:", parray)

	matrix1 := [4][4]int{{1, 2, 3, 4}, {1, 2, 3, 4}, {0, 0, 0, 0}, {1, 2, 3, 4}}
	matrix2 := [4][4]int{{5, 6, 7, 8}, {1, 2, 3, 4}, {1, 2, 3, 4}, {5, 6, 7, 8}}
	addmatrix := c.Add(matrix1, matrix2) //[[6 8 10 12] [2 4 6 8] [1 2 3 4] [6 8 10 12]]
	submatrix := c.Sub(matrix1, matrix2)
	mulmatrix := c.Mul(matrix1, matrix2)
	divmatrix := c.Div(matrix1, matrix2)
	fmt.Println("Matrix 1:", matrix1)
	fmt.Println("Matrix 2:", matrix2)
	fmt.Println("Add Matrix:", addmatrix)
	fmt.Println("Sub Matrix:", submatrix)
	fmt.Println("Mul Matrix:", mulmatrix)
	fmt.Println("Div Matrix:", divmatrix)

	word := "ABCDEFGHIOUPabcdefghioup"
	withoutvowels := f.StringByteVowelString(word)
	fmt.Println("Original string:", word)
	fmt.Println("Filtered String:", withoutvowels)
}