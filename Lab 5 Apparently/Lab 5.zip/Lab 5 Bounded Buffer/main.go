package main

import (
	"fmt"
	"sync"
)

/*
	NOTE-TO-SELF: NOUNDED BUFFER CASE
	- Slice of fixed buffer size acts as buffer
	- Produce function keeps adding to slice
	- Consume function keeps decreasing from slice
	- Producer cannot add more than slice size
	- Consumer cannot consume below slice size is 0
	- Sir said use mutexes
	- I have assumed bound to be 10 which is the size of my buffer constant
	- I nitially filled some of the slice in case the consumer thread runs before the producer thread so we can see both possibilities on runtime
*/

const buffer = 10

var queue = []int{1, 2, 3, 4, 5}

func produce(wg *sync.WaitGroup, m *sync.Mutex) {
	// m.Lock();
	// for len(queue) < buffer {
	// 	queue = append(queue, (len(queue)+1));
	// 	fmt.Println("Producer produces ", len(queue));
	// }
	for true {
		if len(queue) < buffer {
			m.Lock()
			queue = append(queue, (len(queue) + 1))
			fmt.Println("Producer produces ", len(queue))
			// fmt.Println(queue);
			m.Unlock()
		} else {
			break
		}
	}
	// if len(queue) < buffer {
	// 	queue = append(queue, (len(queue)+1));
	// 	fmt.Println("Producer produces ", len(queue));
	// }
	// m.Unlock();
	wg.Done()
}

func consume(wg *sync.WaitGroup, m *sync.Mutex) {
	// m.Lock();
	// for len(queue) > 0 {
	// 	fmt.Println("Consumer consumes ", len(queue));
	// 	queue = queue[:len(queue)-1];
	// }
	for true {
		if len(queue) > 0 {
			m.Lock()
			queue = queue[:len(queue)-1]
			fmt.Println("Consumer consumes ", (len(queue) + 1))
			// fmt.Println(queue);
			m.Unlock()
		} else {
			break
		}
	}
	// if len(queue) > 0 {
	// 	fmt.Println("Consumer consumes ", len(queue));
	// 	queue = queue[:len(queue)-1];
	// }
	// m.Unlock();
	wg.Done()
}

func main() {
	//Actual bounded buffer producer-consumer problem program
	var wg sync.WaitGroup
	var m sync.Mutex

	wg.Add(2)

	go produce(&wg, &m)
	go consume(&wg, &m)

	wg.Wait()

	// fmt.Println("Chal raha hai bhai");
	// fmt.Println(buffer);
	// fmt.Println(queue);
}
