package main

import (
	"fmt"
	"sync"
)

/*
	NOTE-TO-SELF: UNBOUNDED BUFFER CASE
	- Slice of unbounded size
	- Produce function keeps adding to slice
	- Consume function keeps decreasing from slice
	- Consumer cannot consume below slice size is 0
	- I initially filled some of the slice in case the consumer thread runs before the producer thread so we can see both possibilities on runtime
	- Removed buffer check in produce function
*/

var queue = []int{1, 2, 3, 4}

func produce(wg *sync.WaitGroup, m *sync.Mutex) {
	// m.Lock();
	// for len(queue) < buffer {
	// 	queue = append(queue, (len(queue)+1));
	// 	fmt.Println("Producer produces ", len(queue));
	// }
	// for true {
	// 	if len(queue) < buffer {
	m.Lock()
	queue = append(queue, (len(queue) + 1))
	fmt.Println("Producer produces ", len(queue))
	// fmt.Println(queue);
	m.Unlock()
	// 	} else {
	// 		break
	// 	}
	// }
	// if len(queue) < buffer {
	// 	queue = append(queue, (len(queue)+1));
	// 	fmt.Println("Producer produces ", len(queue));
	// }
	// m.Unlock();
	wg.Done()
}

func consume(wg *sync.WaitGroup, m *sync.Mutex) {
	// m.Lock();
	// for len(queue) > 0 {
	// 	fmt.Println("Consumer consumes ", len(queue));
	// 	queue = queue[:len(queue)-1];
	// }
	for true {
		if len(queue) > 0 {
			m.Lock()
			queue = queue[:len(queue)-1]
			fmt.Println("Consumer consumes ", (len(queue) + 1))
			// fmt.Println(queue);
			m.Unlock()
		} else {
			break
		}
	}
	// if len(queue) > 0 {
	// 	fmt.Println("Consumer consumes ", len(queue));
	// 	queue = queue[:len(queue)-1];
	// }
	// m.Unlock();
	wg.Done()
}

func main() {
	//Actual bounded buffer producer-consumer problem program
	var wg sync.WaitGroup
	var m sync.Mutex

	wg.Add(11)

	for i := 0; i < 10; i++ {
		go produce(&wg, &m)
	}
	go consume(&wg, &m)

	wg.Wait()

	// fmt.Println("Chal raha hai bhai");
	// fmt.Println(buffer);
	// fmt.Println(queue);
}
