package main

import (
	"fmt"
	"math/rand"
	"sync"
	"time"
)

var wg sync.WaitGroup

func PrintAlphabet(m *sync.Mutex) {
	m.Lock()
	defer m.Unlock()
	alphabet := "abcdefghijklmnopqrstuvwxyz"
	for _, v := range alphabet {
		// time.Sleep(200 * time.Millisecond) //Just for showing the printing behavior
		fmt.Printf("%c ", v)
	}
	time.Sleep(time.Millisecond)
	fmt.Println()
	wg.Done()
}

func PrintNumbers(m *sync.Mutex) {
	m.Lock()
	defer m.Unlock()
	for i := 1; i <= 26; i++ {
		// time.Sleep(200 * time.Millisecond) //Just for showing the printing behavior
		fmt.Printf("%d ", i)
	}
	time.Sleep(time.Millisecond)
	fmt.Println()
	wg.Done()
}

// func diningProblem(name string, first, second *sync.Mutex, firstName, secondName string) {
// 	for i := 0; i < 100; i++ {
// 		fmt.Printf("(%s) Try to eat\n", name)
// 		first.Lock()
// 		fmt.Printf("(%s) Grab %s\n", name, firstName)
// 		second.Lock()
// 		fmt.Printf("(%s) Grab %s\n", name, secondName)
// 		fmt.Printf("(%s) Eating\n", name)
// 		time.Sleep(time.Duration(rand.Int()) * time.Millisecond)
// 		second.Unlock()
// 		first.Unlock()
// 	}
// 	wg.Done()
// }

func main() {
	rand.Seed(time.Now().UnixNano())

	wg.Add(2)
	m := &sync.Mutex{}

	// go diningProblem("A", fork, spoon, "Fork", "Spoon")
	// go diningProblem("B", spoon, fork, "Spoon", "Fork")

	go PrintAlphabet(m)
	go PrintNumbers(m)

	wg.Wait()
}
