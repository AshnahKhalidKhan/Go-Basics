package secondpackage

import "fmt"

func Function1FromSecondPackage() {
	fmt.Println("This is second package ki file 1")
}